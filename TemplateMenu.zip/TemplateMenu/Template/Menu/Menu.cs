﻿using System.Linq;
using easyInputs;
using Photon.Pun;
using UnityEngine;
using UnityEngine.UI;

namespace Template.Menu
{
    /*
     THIS TEMPLATE IS MADE OF COLOSSAL CHEAT MENU
     THIS TEMPLATE IS MADE BY SILENT (@s1lnt)
     ALL COMMENTS ARE TO HELP OUT
     https://discord.gg/zmbGV74y8W

	 SCROLL DOWN FIND "MenuName" change it to your menu name and "MenuColour" your menu colour
     */

    public class MenuOption
    {
        public string DisplayName;
        public string _type;
        public bool AssociatedBool;
        public string AssociatedString;
        public float AssociatedFloat;
        public int AssociatedInt;
    }

    public class Menu
	{
		public static bool GUIToggled = true;

        // Dont touch this OR YOUR MENU WILL FUCKING BREAK 👍
        private static GameObject HUDObj;
		private static GameObject HUDObj2;
		private static GameObject MainCamera;
		private static Text Testtext;
		private static Material AlertText = new Material(Shader.Find("GUI/Text Shader"));
		private static Text NotifiText;
		public static string MenuState = "Main";
		public static int SelectedOptionIndex = 0;

		public static MenuOption[] CurrentViewingMenu = null;
		public static MenuOption[] MainMenu;
		public static MenuOption[] Movement; 
        //public static MenuOption[] YourOption; 

        // -- Change these --

        public static string MenuColour = "magenta"; // your menu color
        public static string MenuName = "TEMPLATE"; // your menu name

        // -- -- --

        public static bool inputcooldown = false;
		public static bool menutogglecooldown = false;

		public static void LoadOnce()
		{

            // Dont touch this vvv --- 
            MainCamera = GameObject.Find("Main Camera");
			HUDObj = new GameObject();
			HUDObj2 = new GameObject();
			HUDObj2.name = "CLIENT_HUB";
			HUDObj.name = "CLIENT_HUB";
			HUDObj.AddComponent<Canvas>();
			HUDObj.AddComponent<CanvasScaler>();
			HUDObj.AddComponent<GraphicRaycaster>();
			HUDObj.GetComponent<Canvas>().enabled = true;
			HUDObj.GetComponent<Canvas>().renderMode = RenderMode.WorldSpace;
			HUDObj.GetComponent<Canvas>().worldCamera = MainCamera.GetComponent<Camera>();
			HUDObj.GetComponent<RectTransform>().sizeDelta = new Vector2(5f, 5f);
			HUDObj.GetComponent<RectTransform>().position = new Vector3(MainCamera.transform.position.x, MainCamera.transform.position.y, MainCamera.transform.position.z);
			HUDObj2.transform.position = new Vector3(MainCamera.transform.position.x, MainCamera.transform.position.y, MainCamera.transform.position.z - 4.6f);
			HUDObj.transform.parent = HUDObj2.transform;
			HUDObj.GetComponent<RectTransform>().localPosition = new Vector3(0f, 0f, 1.6f);
			Vector3 eulerAngles = HUDObj.GetComponent<RectTransform>().rotation.eulerAngles;
			eulerAngles.y = -270f;
			HUDObj.transform.localScale = new Vector3(1f, 1f, 1f);
			HUDObj.GetComponent<RectTransform>().rotation = Quaternion.Euler(eulerAngles);
			Testtext = new GameObject
			{
				transform = 
				{
					parent = HUDObj.transform
				}
			}.AddComponent<Text>();
			Testtext.text = ""; // You can add something here but it might break
			Testtext.fontSize = 10;
			Testtext.font = GameObject.Find("COC Text").GetComponent<Text>().font;  // Resources.LoadResource<Font>("Arial") as Font; | fix this your self if you dont want coc text
			Testtext.rectTransform.sizeDelta = new Vector2(260f, 160f);
			Testtext.alignment = TextAnchor.UpperLeft;
			Testtext.rectTransform.localScale = new Vector3(0.01f, 0.01f, 1f);
			Testtext.rectTransform.localPosition = new Vector3(-1.5f, 1f, 2f);
			Testtext.material = AlertText;
			NotifiText = Testtext;
			HUDObj2.transform.transform.position = new Vector3(MainCamera.transform.position.x, MainCamera.transform.position.y, MainCamera.transform.position.z);
			HUDObj2.transform.rotation = MainCamera.transform.rotation;

			// --Above ^^ --

            // This is the actual menu stuff that shows 
            // DisplayName is the actual thing youll see
            // _type is what its doing so like ( "submenu" opens a new menu, "button" does something once and "toggle" is a toggle
            // AssociatedString is your actual button/menuoption for your submenu or button
            // AssociatedBool is your bool for toggling mods

			// MainMenu = new MenuOption[1]; (this would be [2]) | this is your amount of mods ALWAYS keep this 1 number of mods you have 
			// MainMenu[0] = new MenuOption { DisplayName = "Movement", _type = "submenu", AssociatedString = "Movement" };
			// MainMenu[1] = new MenuOption { DisplayName = "New Option", _type = "submenu", AssociatedString = "YourOption" };

            MainMenu = new MenuOption[1];
			MainMenu[0] = new MenuOption { DisplayName = "Movement", _type = "submenu", AssociatedString = "Movement" };

			Movement = new MenuOption[2];
			Movement[0] = new MenuOption { DisplayName = "ExcelFly", _type = "toggle", AssociatedBool = false };
			Movement[1] = new MenuOption { DisplayName = "Back", _type = "submenu", AssociatedString = "Back" };

			MenuState = "Main"; // Dont touch this
			CurrentViewingMenu = MainMenu; // Dont touch this

            UpdateMenuState(new MenuOption(), null, null); // Dont touch this
        }

		public static void Load() // Dont touch this
        {
			bool State = EasyInputs.GetThumbStickButtonDown(EasyHand.LeftHand); // Dont touch this 
            bool State1 = EasyInputs.GetThumbStickButtonDown(EasyHand.RightHand); // Dont touch this
            if (State && State1 && !menutogglecooldown) // Dont touch this
            {
				menutogglecooldown = true; // Dont touch this
                HUDObj2.active = !HUDObj2.active; // Dont touch this
                GUIToggled = !GUIToggled; // Dont touch this
            }

			if (!State && !State1 && menutogglecooldown)
            {   // Dont touch this
                menutogglecooldown = false;
			}

			if (GUIToggled)
			{
				HUDObj2.transform.position = new Vector3(MainCamera.transform.position.x, MainCamera.transform.position.y, MainCamera.transform.position.z);
				HUDObj2.transform.rotation = MainCamera.transform.rotation;

				// If you dont want the menu to shake when you hit the ground etc. remove the comment below
				//HUDObj2.transform.SetParent(MainCamera.transform);

                if (EasyInputs.GetThumbStickButtonDown(EasyHand.LeftHand)) // Dont touch this
                {
                    bool Down = EasyInputs.GetTriggerButtonDown(EasyHand.RightHand); // Dont touch this 
                    bool Select = EasyInputs.GetGripButtonDown(EasyHand.RightHand); // Dont touch this

                    if (Down && !inputcooldown) // Dont touch this
                    {
                        inputcooldown = true;
                        if (SelectedOptionIndex + 1 == CurrentViewingMenu.Count<MenuOption>())
                        {
                            SelectedOptionIndex = 0;
                        }
                        else
                        {
                            SelectedOptionIndex++;
                        }
                        UpdateMenuState(new MenuOption(), null, null);
                    }
                    if (Select && !inputcooldown)
                    {
                        inputcooldown = true;
                        UpdateMenuState(CurrentViewingMenu[SelectedOptionIndex], null, "optionhit");
                    }
                    if (!Select && !Down && inputcooldown)
                    {
                        inputcooldown = false;
                    }
                }
            }

			// your mod bools | go down and find buttons for buttons
			Plugin.excelfly = Movement[0].AssociatedBool;
			//Plugin.yourmod = Movement[1].AssociatedBool;
		}

		private static void UpdateMenuState(MenuOption option, string _MenuState, string OperationType) // Dont touch this
        {
			try
			{
				if (OperationType == "optionhit") // Dont touch this
                {
					if (option._type == "submenu") // Dont touch this 
                    {
						// your actual options so like add Visual here CurrentViewingMenu = Visual
						if (option.AssociatedString == "Movement") 
						{
							CurrentViewingMenu = Movement;
						}

						if (option.AssociatedString == "Back") 
						{
							CurrentViewingMenu = MainMenu;
						}

						MenuState = option.AssociatedString; // Dont touch this
                        SelectedOptionIndex = 0; // Dont touch this
                    }

					if (option._type == "toggle") // Dont touch this
                    {
						if (!option.AssociatedBool)
						{
							option.AssociatedBool = true;
							//Debug.Log(string.Format("<color=magenta>Toggled {0} : {1}</color>", option.DisplayName, option.AssociatedBool));
						}
						else
						{
							option.AssociatedBool = false;
						}
					}
					if (option._type == "button") // BUTTONS
					{
						// to make a button do this
						if (option.AssociatedString == "Disconnect") // example
						{
							PhotonNetwork.Disconnect(); // code here runs once
						}
					}
				}
			}
			catch
			{
			}

            // Dont touch this
            string ToDraw = $"<color={MenuColour}>{MenuName} : {MenuState}</color>\n";
            int i = 0;
			if (CurrentViewingMenu != null)
			{
				foreach (MenuOption opt in CurrentViewingMenu)
				{
					if (SelectedOptionIndex == i)
						ToDraw = ToDraw + ">";
					ToDraw = ToDraw + opt.DisplayName;

					if (opt._type == "toggle")
					{
						if (opt.AssociatedBool == true)
						{
							ToDraw = ToDraw + $" <color={MenuColour}>[ON]</color>";
						}
						else
							ToDraw = ToDraw + " <color=red>[OFF]</color>";
					}

					ToDraw = ToDraw + "\n";
					i++;
				}
				Testtext.text = ToDraw;
			}
			else
			{
				Debug.Log("Null for some reason");
			}
        }
	}
}
