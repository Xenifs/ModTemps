﻿using Template;
using MelonLoader;
using Template.Mods;

[assembly: MelonInfo(typeof(Plugin), "Template", "1.0.0", "Silent")]
[assembly: MelonGame(null, null)]
namespace Template
{
    /*
     THIS TEMPLATE IS MADE OF COLOSSAL CHEAT MENU
     THIS TEMPLATE IS MADE BY SILENT (@s1lnt)
     ALL COMMENTS ARE TO HELP OUT
     https://discord.gg/zmbGV74y8W
     */
    public class Plugin : MelonMod
	{
		static bool doonce = false;
		public override void OnUpdate()
		{
			if (!doonce)
			{
				Menu.Menu.LoadOnce(); // Loads the menu start function
				doonce = true;
			}
			Menu.Menu.Load(); // Loads the menu fully and makes it work
			this.ModManager(); // Loads your mods
		}

		private void ModManager()
		{
			if (excelfly) // if mod is enabled
			{
				// do the mod
				Movement.ExcelFly();
			}
		}


		// Your mod bools
		public static bool excelfly = false;
	}
}
