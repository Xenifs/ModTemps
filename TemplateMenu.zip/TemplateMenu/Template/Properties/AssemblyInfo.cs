﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyTitle("ColossalCheatMenuV2")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("16275-724")]
[assembly: AssemblyProduct("ColossalCheatMenuV2")]
[assembly: AssemblyCopyright("Copyright © 16275-724 2023")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("bc3a1af1-57ad-4dd6-b6a5-30d21cd80bc6")]
[assembly: AssemblyFileVersion("1.0.0.0")]
