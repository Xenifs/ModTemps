﻿using UnityEngine;
using GorillaLocomotion;
using easyInputs;

namespace Template.Mods
{
    /*
     THIS TEMPLATE IS MADE OF COLOSSAL CHEAT MENU
     THIS TEMPLATE IS MADE BY SILENT (@s1lnt)
     ALL COMMENTS ARE TO HELP OUT
     https://discord.gg/zmbGV74y8W
     */


    // Hi skids if you havent coded before read this

    /*
     To Get Primary Button do "EasyInputs.GetPrimaryButtonDown(EasyHand.RightHand);" | RightHand can be LeftHand
     To Get Secondary Button do "EasyInputs.GetSecondaryButtonDown(EasyHand.RightHand);" | RightHand can be LeftHand
     To Get Trigger Button do "EasyInputs.GetTriggerButtonDown(EasyHand.RightHand);" | RightHand can be LeftHand
     To Get Grip Button do "EasyInputs.GetGripButtonDown(EasyHand.RightHand);" | RightHand can be LeftHand

     ---------

     To get your actual Player with movement do
     GorillaLocomotion.Player.Instance
     
     To Get your actual rig (what you see and what others see not your movement) do
     GorillaTagger.instance.myVRRig
     */

    public class Movement
    {
        public static void ExcelFly() // this is a easy mod
        {
            // Get your left primary button
            if (EasyInputs.GetPrimaryButtonDown(EasyHand.LeftHand))
            {
                // Get your velocity and make it your left hand
                GorillaLocomotion.Player.Instance.bodyCollider.attachedRigidbody.velocity += -GorillaLocomotion.Player.Instance.leftHandTransform.right / 2f; // 1f is fast and 8f is slow
            }
            // Get your right primary button
            if (EasyInputs.GetPrimaryButtonDown(EasyHand.RightHand))
            {
                // Get your velocity and make it your right hand
                GorillaLocomotion.Player.Instance.bodyCollider.attachedRigidbody.velocity += GorillaLocomotion.Player.Instance.rightHandTransform.right / 2f; // 1f is fast and 8f is slow
            }
            // thats how you make excel fly
        }
    }
}
