﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using Template;
using MelonLoader;
//Made By Zinx & Credits To Maximility
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: MelonInfo(typeof(Plugin), "MenuTemplate", "1.0.0", "Template", "")]
[assembly: MelonGame(null, null)]
[assembly: AssemblyTitle("")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("18868-13842")]
[assembly: AssemblyProduct("")]
[assembly: AssemblyCopyright("Copyright © 18868-13842 2023")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("ca8c2ec1-a3f9-4480-bd57-ed61addb5e25")]
[assembly: AssemblyFileVersion("1.0.0.0")]
