﻿using System;
using System.Linq;
using easyInputs;
using Photon.Pun;
using UnityEngine;
using UnhollowerBaseLib;
using UnityEngine.UI;

namespace Template.Menu
{
    #region MADEBYZINX
	//dont delete this if you do you skidding and thats annoying
	//also dont mess up anything
    #endregion
    public class Menu
	{
		#region Bools
		private static GameObject menu = null;
		private static GameObject canvasObj = null;
		private static GameObject reference = null;
		private static bool[] Page1inrange = new bool[21]; // always keep this 1 above the amount of buttons there is
		public static bool[] Page1ButtonActive = new bool[21];// always keep this 1 above the amount of buttons there is	
		public static string Page = "1"; // ignore this
		private static bool[] PageButton = new bool[7];// always keep this 1 above the amount of pages there is	
		public static Material MenuTheme = new Material(Shader.Find("Sprites/Default"));
		public static string MenuColorType = "normal";
		private static float offset;
		private static float lastClickTime = 0.0f;
		public static float cooldownDuration = 0.25f;
		private static float elapsedTime = 0f;
		private static Color ButtonClicked;
		private static Color ButtonNotClicked;
		private static Color startColor = Color.red;
		private static Color endColor = Color.black;
		private static float transitionDuration = 3f;
		public static float proximityRange = 0.037f;
		#endregion
		#region Menu
		public static void Draw()
		{
			menu = GameObject.CreatePrimitive(PrimitiveType.Cube);
			UnityEngine.Object.Destroy(menu.GetComponent<Rigidbody>());
			UnityEngine.Object.Destroy(menu.GetComponent<BoxCollider>());
			UnityEngine.Object.Destroy(menu.GetComponent<Renderer>());
			menu.transform.localScale = new Vector3(0.1f, 0.29f, 0.4f);
			GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
			UnityEngine.Object.Destroy(gameObject.GetComponent<Rigidbody>());
			UnityEngine.Object.Destroy(gameObject.GetComponent<BoxCollider>());
			gameObject.transform.parent = menu.transform;
			gameObject.transform.rotation = Quaternion.identity;
			gameObject.transform.localScale = new Vector3(0.1f, 1.05f, 0.9f);
			gameObject.GetComponent<Renderer>().material = MenuTheme;
			gameObject.transform.position = new Vector3(0.05f, 0f, 0f);
			canvasObj = new GameObject();
			canvasObj.transform.parent = menu.transform;
			Canvas canvas = canvasObj.AddComponent<Canvas>();
			CanvasScaler canvasScaler = canvasObj.AddComponent<CanvasScaler>();
			canvasObj.AddComponent<GraphicRaycaster>();
			canvas.renderMode = RenderMode.WorldSpace;
			canvasScaler.dynamicPixelsPerUnit = 1000f;
			GameObject gameObject2 = new GameObject();
			gameObject2.transform.parent = canvasObj.transform;
			Text text = gameObject2.AddComponent<Text>();
			text.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
			text.text = " Help menu "; // change the name poo poo head
			text.fontSize = 1;
			text.alignment = TextAnchor.MiddleCenter;
			text.resizeTextForBestFit = true;
			text.resizeTextMinSize = 0;
			RectTransform component = text.GetComponent<RectTransform>();
			component.localPosition = Vector3.zero;
			component.sizeDelta = new Vector2(0.28f, 0.05f);
			component.position = new Vector3(0.06f, 0f, 0.145f);// 0.215f = 0.205f
			component.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
		}
		#endregion
		#region Buttons
		public static void DrawPageButton(string Text, float textypos, float buttonypos, string Pagenum, ref bool Button, int index) {GameObject DisButton = GameObject.CreatePrimitive(PrimitiveType.Cube); UnityEngine.Object.Destroy(DisButton.GetComponent<Rigidbody>()); UnityEngine.Object.Destroy(DisButton.GetComponent<BoxCollider>());DisButton.transform.parent = menu.transform;DisButton.transform.rotation = menu.transform.rotation;DisButton.transform.localScale = new Vector3(0.05f, 0.8f, 0.08f); DisButton.transform.localPosition = new Vector3(0.54f, 0f, buttonypos - offset / 1.2f);  Text text2 = new GameObject { transform = {parent = canvasObj.transform} }.AddComponent<Text>();text2.font = Resources.GetBuiltinResource<Font>("Arial.ttf");text2.text = Text;text2.color = Color.white;text2.fontSize = 1;text2.alignment = TextAnchor.MiddleCenter;text2.resizeTextForBestFit = true;text2.resizeTextMinSize = 0;RectTransform component = text2.GetComponent<RectTransform>();component.localPosition = Vector3.zero;component.sizeDelta = new Vector2(0.2f, 0.03f);component.localPosition = new Vector3(0.064f, 0f, textypos - offset / 3.05f); Quaternion newRotation = DisButton.transform.rotation * Quaternion.Euler(180f, 90f, 90f); component.rotation = newRotation; float isclicked = Vector3.Distance(DisButton.transform.position, reference.transform.position); if (isclicked <= proximityRange && Time.time - lastClickTime > cooldownDuration) { Button = true; PageButton[index] = Button; Page = Pagenum; GorillaTagger.Instance.offlineVRRig.PlayHandTap(4, false, 0.05f); GameObject.Destroy(menu); GameObject.Destroy(reference); menu = null; reference = null; lastClickTime = Time.time; } else if (isclicked > proximityRange) { Button = false; PageButton[index] = Button; } if (Button) { DisButton.GetComponent<Renderer>().material.color = ButtonClicked; } else { DisButton.GetComponent<Renderer>().material.color = ButtonNotClicked; } GameObject.Destroy(DisButton, Time.deltaTime); GameObject.Destroy(text2, Time.deltaTime);}
		public static void Drawsingleclickbutton(string Text, float textypos, float buttonypos, ref bool ButtonRange, ref bool Mod, int index) {GameObject DisButton = GameObject.CreatePrimitive(PrimitiveType.Cube); UnityEngine.Object.Destroy(DisButton.GetComponent<Rigidbody>()); UnityEngine.Object.Destroy(DisButton.GetComponent<BoxCollider>()); DisButton.transform.parent = menu.transform; DisButton.transform.rotation = menu.transform.rotation; DisButton.transform.localScale = new Vector3(0.05f, 0.8f, 0.08f); DisButton.transform.localPosition = new Vector3(0.54f, 0f, buttonypos - offset / 1.2f);Text text2 = new GameObject { transform = { parent = canvasObj.transform } }.AddComponent<Text>();text2.font = Resources.GetBuiltinResource<Font>("Arial.ttf");text2.text = Text; text2.color = Color.white; text2.fontSize = 1; text2.alignment = TextAnchor.MiddleCenter; text2.resizeTextForBestFit = true; text2.resizeTextMinSize = 0; RectTransform component = text2.GetComponent<RectTransform>(); component.localPosition = Vector3.zero; component.sizeDelta = new Vector2(0.2f, 0.03f); component.localPosition = new Vector3(0.064f, 0f, textypos - offset / 3.05f); Quaternion newRotation = DisButton.transform.rotation * Quaternion.Euler(180f, 90f, 90f); component.rotation = newRotation; float isclicked = Vector3.Distance(DisButton.transform.position, reference.transform.position); if (isclicked <= proximityRange && !ButtonRange && Time.time - lastClickTime > cooldownDuration) { ButtonRange = true; Mod = !Mod; GorillaTagger.Instance.offlineVRRig.PlayHandTap(4, false, 0.05f); lastClickTime = Time.time; } else if (isclicked > proximityRange && ButtonRange) {ButtonRange = false; } if (Mod) { DisButton.GetComponent<Renderer>().material.color = ButtonClicked; } else { DisButton.GetComponent<Renderer>().material.color = ButtonNotClicked; } Page1inrange[index] = ButtonRange; Page1ButtonActive[index] = Mod; GameObject.Destroy(DisButton, Time.deltaTime); GameObject.Destroy(text2, Time.deltaTime);}
        #endregion
        public static void Prefix()
		{
			if (EasyInputs.GetSecondaryButtonDown(EasyHand.LeftHand) && menu == null)
			{
				// dont mess with this or your menu wont work
				Draw(); if (reference == null) { reference = GameObject.CreatePrimitive(PrimitiveType.Sphere); GameObject.Destroy(reference.GetComponent<SphereCollider>()); reference.transform.parent = GorillaLocomotion.Player.Instance.rightHandTransform; reference.transform.localPosition = new Vector3(0f, 0f, 0.1f); reference.transform.localScale = new Vector3(0.01f, 0.01f, 0.01f); }
			}
			else
			{
				if (!EasyInputs.GetSecondaryButtonDown(EasyHand.LeftHand) && menu != null)
				{
					// dont mess with this or your menu wont work
					menu.AddComponent<Rigidbody>(); reference.AddComponent<Rigidbody>(); menu.GetComponent<Rigidbody>().velocity = new Vector3(UnityEngine.Random.Range(-1, 1), UnityEngine.Random.Range(-1, 1), UnityEngine.Random.Range(-1, 1)); menu.GetComponent<Rigidbody>().angularVelocity = new Vector3(UnityEngine.Random.Range(-33, 33), UnityEngine.Random.Range(-33, 33), UnityEngine.Random.Range(-33, 33)); GameObject.Destroy(menu, 3); GameObject.Destroy(reference); menu = null; reference = null;
				}
			}
			if (EasyInputs.GetSecondaryButtonDown(EasyHand.LeftHand) && menu != null)
			{
				// dont mess with this or your menu wont work
				menu.transform.position = GorillaLocomotion.Player.Instance.leftHandTransform.position; menu.transform.rotation = GorillaLocomotion.Player.Instance.leftHandTransform.rotation;
			}
			if (EasyInputs.GetSecondaryButtonDown(EasyHand.LeftHand) && menu != null)
			{
				
				if (Page == "1")
				{
                    Drawsingleclickbutton("Disconnect", 0.186f, 0.45f, ref Page1inrange[3], ref Page1ButtonActive[3], 3);
                    DrawPageButton("-------->", 0.077f, 0.19f, "2", ref PageButton[2], 2);
					DrawPageButton("<--------", 0.037f, 0.09f, "2", ref PageButton[2], 2); // make this go to the last page
                    DrawPageButton("Visuals", -0.003f, -0.01f, "Visuals", ref PageButton[2], 2);
                    DrawPageButton("Movement", -0.043f, -0.11f, "Movement", ref PageButton[3], 3);
                    DrawPageButton("Overpowered", -0.083f, -0.21f, "Overpowered", ref PageButton[4], 4);
                    Drawsingleclickbutton("", -0.123f, -0.31f, ref Page1inrange[4], ref Page1ButtonActive[4], 4);
				}
				if (Page == "Visuals")
				{
                    Drawsingleclickbutton("Disconnect", 0.186f, 0.45f, ref Page1inrange[3], ref Page1ButtonActive[3], 3);
                    DrawPageButton("-------->", 0.077f, 0.19f, "Visuals", ref PageButton[1], 1); // for page3 put DrawPageButton("-------->", 0.157f, 0.39f, "3", ref PageButton[3], 3);
                    DrawPageButton("Exit", 0.037f, 0.09f, "1", ref PageButton[1], 1);
                    Drawsingleclickbutton("", -0.003f, -0.01f, ref Page1inrange[5], ref Page1ButtonActive[5], 5);
					Drawsingleclickbutton("", -0.043f, -0.11f, ref Page1inrange[6], ref Page1ButtonActive[6], 6);
					Drawsingleclickbutton("", -0.083f, -0.21f, ref Page1inrange[7], ref Page1ButtonActive[7], 7);
					Drawsingleclickbutton("", -0.123f, -0.31f, ref Page1inrange[8], ref Page1ButtonActive[8], 8);
				}
				if (Page == "Movement")
				{
                    Drawsingleclickbutton("Disconnect", 0.186f, 0.45f, ref Page1inrange[3], ref Page1ButtonActive[3], 3);
                    DrawPageButton("-------->", 0.077f, 0.19f, "Movement1", ref PageButton[5], 5); // for page3 put DrawPageButton("-------->", 0.157f, 0.39f, "3", ref PageButton[3], 3);
                    DrawPageButton("Exit", 0.037f, 0.09f, "1", ref PageButton[1], 1);
                    Drawsingleclickbutton("", -0.003f, -0.01f, ref Page1inrange[9], ref Page1ButtonActive[9], 9);
                    Drawsingleclickbutton("", -0.043f, -0.11f, ref Page1inrange[10], ref Page1ButtonActive[10], 10);
                    Drawsingleclickbutton("", -0.083f, -0.21f, ref Page1inrange[11], ref Page1ButtonActive[11], 11);
                    Drawsingleclickbutton("", -0.123f, -0.31f, ref Page1inrange[12], ref Page1ButtonActive[12], 12);
                }
                if (Page == "Overpowered")
                {
                    Drawsingleclickbutton("Disconnect", 0.186f, 0.45f, ref Page1inrange[3], ref Page1ButtonActive[3], 3);
                    DrawPageButton("-------->", 0.077f, 0.19f, "1", ref PageButton[1], 1); // for page3 put DrawPageButton("-------->", 0.157f, 0.39f, "3", ref PageButton[3], 3);
                    DrawPageButton("Exit", 0.037f, 0.09f, "1", ref PageButton[1], 1);
                    Drawsingleclickbutton("", -0.003f, -0.01f, ref Page1inrange[13], ref Page1ButtonActive[13], 13);
                    Drawsingleclickbutton("", -0.043f, -0.11f, ref Page1inrange[14], ref Page1ButtonActive[14], 14);
                    Drawsingleclickbutton("", -0.083f, -0.21f, ref Page1inrange[15], ref Page1ButtonActive[15], 15);
                    Drawsingleclickbutton("", -0.123f, -0.31f, ref Page1inrange[16], ref Page1ButtonActive[16], 16);
                }
                if (Page == "Movement1")
                {
                    Drawsingleclickbutton("Disconnect", 0.186f, 0.45f, ref Page1inrange[3], ref Page1ButtonActive[3], 3);
                    DrawPageButton("-------->", 0.077f, 0.19f, "Movement2", ref PageButton[6], 6);
                    DrawPageButton("<--------", 0.037f, 0.09f, "Movement", ref PageButton[1], 1); // make this go to the last page
                    Drawsingleclickbutton("", -0.003f, -0.01f, ref Page1inrange[17], ref Page1ButtonActive[17], 17);
                    Drawsingleclickbutton("", -0.043f, -0.11f, ref Page1inrange[18], ref Page1ButtonActive[18], 18);
                    Drawsingleclickbutton("", -0.083f, -0.21f, ref Page1inrange[19], ref Page1ButtonActive[19], 19);
                    Drawsingleclickbutton("", -0.123f, -0.31f, ref Page1inrange[20], ref Page1ButtonActive[20], 20);
                }
                if (Page == "Movement2")
                {
                    Drawsingleclickbutton("Disconnect", 0.186f, 0.45f, ref Page1inrange[3], ref Page1ButtonActive[3], 3);
                    DrawPageButton("-------->", 0.077f, 0.19f, "Movement", ref PageButton[1], 1);
                    DrawPageButton("<--------", 0.037f, 0.09f, "Movement1", ref PageButton[1], 1); // make this go to the last page
                    Drawsingleclickbutton("", -0.003f, -0.01f, ref Page1inrange[24], ref Page1ButtonActive[24], 21);
                    Drawsingleclickbutton("", -0.043f, -0.11f, ref Page1inrange[24], ref Page1ButtonActive[24], 22);
                    Drawsingleclickbutton("", -0.083f, -0.21f, ref Page1inrange[24], ref Page1ButtonActive[24], 23);
                    Drawsingleclickbutton("", -0.123f, -0.31f, ref Page1inrange[24], ref Page1ButtonActive[24], 24);
                }
            }
			#region TheButtonActivationThings
			// page 1
			if (Page1ButtonActive[1])
			{
				Application.Quit();
			}
			if (Page1ButtonActive[2])
			{
				PhotonNetwork.JoinRandomRoom();
				Page1ButtonActive[2] = false;
			}
			if (Page1ButtonActive[3])
			{
				PhotonNetwork.Disconnect();
				Page1ButtonActive[3] = false;
			}
			if (Page1ButtonActive[4])
			{
				
			}

			//Visuals
			if (Page1ButtonActive[5])
			{
				
			}
			if (Page1ButtonActive[6])
			{
				
			}
			if (Page1ButtonActive[7])
			{
				

			}
			if (Page1ButtonActive[8])
			{
				
			}

            //Movement
            if (Page1ButtonActive[9])
            {

            }
            if (Page1ButtonActive[10])
            {

            }
            if (Page1ButtonActive[11])
            {


            }
            if (Page1ButtonActive[12])
            {

            }

            //Overpowered
            if (Page1ButtonActive[13])
            {

            }
            if (Page1ButtonActive[14])
            {

            }
            if (Page1ButtonActive[15])
            {


            }
            if (Page1ButtonActive[16])
            {

            }
            #endregion
            #region MenuColorChanger
            if (MenuColorType == "normal")
			{
			    ButtonClicked = new Color(0.4f, 0.4f, 0.4f);
		        ButtonNotClicked = new Color(0.65f, 0.65f, 0.65f);
				// this is the color changer
				if (elapsedTime < transitionDuration) { MenuTheme.color = Color.Lerp(startColor, endColor, elapsedTime / transitionDuration); elapsedTime += Time.deltaTime; if (elapsedTime >= transitionDuration) { elapsedTime = 0f; }
					// dont want the color changer just do MenuTheme.color =  new Color(0.1f, 0.1f, 0.1f); its a random color
				}
			}
            #endregion

        }

    }
}
